# Bikewalaa CRM — MVP

> Digital-first two-wheeler franchise CRM — Lead management, inventory, dynamic pricing & WhatsApp quotations.

![Next.js](https://img.shields.io/badge/Next.js-14-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![Vercel](https://img.shields.io/badge/Deploy-Vercel-black)

---

## ✨ Features (MVP v1.0)

| Module | What it does |
|---|---|
| **Dashboard** | Real-time KPIs, pipeline overview, franchise performance |
| **Lead Management** | 7-stage pipeline, search/filter, notes, stage updates |
| **Inventory** | Stock tracking across 4 franchises, +/− controls |
| **Dynamic Pricing** | Live price editor with margin-floor protection + EMI calculator |
| **WhatsApp Quotation** | One-click quote → opens WhatsApp with pre-filled message |

---

## 🚀 Deploy to Vercel (5 minutes)

### Option A — GitHub + Vercel (Recommended)

1. **Push to GitHub**
   ```bash
   cd bikewalaa-crm
   git init
   git add .
   git commit -m "feat: Bikewalaa CRM MVP"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/bikewalaa-crm.git
   git push -u origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com) → New Project
   - Import your GitHub repo
   - Framework: **Next.js** (auto-detected)
   - Click **Deploy**
   - ✅ Live at `https://bikewalaa-crm.vercel.app`

### Option B — Vercel CLI

```bash
npm install -g vercel
cd bikewalaa-crm
vercel --prod
```

---

## 💻 Run Locally

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Open in browser
http://localhost:3000
```

---

## 🗂️ Project Structure

```
bikewalaa-crm/
├── app/
│   ├── layout.tsx        # Root layout + metadata
│   ├── page.tsx          # Entry point
│   └── globals.css       # Global styles + animations
├── components/
│   ├── CRM.tsx           # App shell + state management
│   ├── Sidebar.tsx       # Navigation sidebar
│   ├── Dashboard.tsx     # KPI dashboard
│   ├── Leads.tsx         # Lead management module
│   ├── Inventory.tsx     # Inventory module
│   ├── Pricing.tsx       # Dynamic pricing + EMI
│   ├── Quotations.tsx    # WhatsApp quotation module
│   ├── data.ts           # Types, seed data, helpers
│   └── ui.tsx            # Reusable UI atoms
├── public/
├── package.json
├── next.config.js
└── tsconfig.json
```

---

## 🔮 Next Steps (Post-MVP)

- [ ] **MongoDB backend** — persistent data storage
- [ ] **JWT authentication** — franchise-specific logins
- [ ] **WhatsApp Business API** — send quotes programmatically
- [ ] **Finance module** — NBFC loan application tracking
- [ ] **Campaign manager** — festival offer creation
- [ ] **Mobile app** — React Native for sales execs

---

## 🏗️ Tech Stack

- **Frontend**: Next.js 14 (App Router) + TypeScript
- **Styling**: Inline CSS (no Tailwind dependency)
- **Fonts**: Syne + DM Mono (Google Fonts)
- **Deployment**: Vercel (free tier)
- **State**: React useState (MVP) → MongoDB + SWR (production)

---

## 📞 Support

Built for Bikewalaa.com — Mumbai & Navi Mumbai City Pilot  
Designed for 3–5 franchises, scalable to 100+
