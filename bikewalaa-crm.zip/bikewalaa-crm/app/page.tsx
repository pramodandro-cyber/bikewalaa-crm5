"use client";
import CRM from "@/components/CRM";

export default function Page() {
  return <CRM />;
}
