import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Bikewalaa CRM",
  description: "Digital-first two-wheeler franchise CRM — Lead management, inventory, pricing & WhatsApp quotations",
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}
