"use client";
import React, { useState } from "react";
import {
  Lead, PricingEntry, STAGES, SOURCES, MASTER_BIKES, FRANCHISES,
  stageOf, bikeOf, franchiseOf, calcOnRoad, formatINR,
  uid, today,
} from "./data";
import { Btn, Badge, Card, Modal, Field, ScoreBadge } from "./ui";

// ─── LEAD ROW ─────────────────────────────────────────────────────────────────

function LeadRow({
  lead, onSelect, onStageChange,
}: { lead: Lead; onSelect: (l: Lead) => void; onStageChange: (id: string, stage: string) => void }) {
  const bike      = bikeOf(lead.bikeId);
  const stage     = stageOf(lead.stage);
  const franchise = franchiseOf(lead.franchiseId);
  return (
    <div
      onClick={() => onSelect(lead)}
      style={{
        display: "grid", gridTemplateColumns: "1fr 140px 130px 120px 100px 80px",
        gap: 16, alignItems: "center", padding: "14px 20px",
        borderBottom: "1px solid #1e2535", cursor: "pointer", transition: "background 0.15s",
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#0a0d14"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
    >
      <div>
        <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{lead.name}</div>
        <div style={{ fontSize: 11, color: "#475569" }}>{lead.phone} · {franchise?.name}</div>
      </div>
      <div style={{ fontSize: 11, color: "#94a3b8" }}>{bike?.img} {bike?.brand} {bike?.model}</div>
      <div>
        <select
          value={lead.stage}
          onClick={e => e.stopPropagation()}
          onChange={e => { e.stopPropagation(); onStageChange(lead.id, e.target.value); }}
          style={{
            padding: "4px 8px", fontSize: 10,
            color: stage.color, background: stage.bg,
            border: `1px solid ${stage.color}40`, borderRadius: 100, width: "auto",
          }}
        >
          {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
        </select>
      </div>
      <div style={{ fontSize: 10, color: "#475569", textTransform: "capitalize" }}>
        {lead.source.replace(/_/g, " ")}
      </div>
      <ScoreBadge score={lead.score} />
      <div style={{ fontSize: 10, color: "#475569" }}>{lead.followUp ?? "—"}</div>
    </div>
  );
}

// ─── LEAD DETAIL ──────────────────────────────────────────────────────────────

function LeadDetail({
  lead, onClose, onUpdate, pricing, setActiveTab, setQuoteTarget,
}: {
  lead: Lead;
  onClose: () => void;
  onUpdate: (l: Lead) => void;
  pricing: Record<string, PricingEntry>;
  setActiveTab: (t: string) => void;
  setQuoteTarget: (l: Lead) => void;
}) {
  const [stage, setStage] = useState(lead.stage);
  const [note, setNote]   = useState("");
  const [notes, setNotes] = useState<string[]>(lead.notes ?? []);
  const bike  = bikeOf(lead.bikeId);
  const p     = pricing[lead.bikeId];
  const onRoad = p ? calcOnRoad(p) : 0;

  const save      = () => { onUpdate({ ...lead, stage, notes }); onClose(); };
  const addNote   = () => { if (note.trim()) { setNotes(n => [...n, note.trim()]); setNote(""); } };
  const openQuote = () => { setQuoteTarget(lead); setActiveTab("quotations"); onClose(); };

  return (
    <Modal title={`Lead · ${lead.name}`} onClose={onClose} width={640}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <div>
          <Field label="Customer"><input value={lead.name}    readOnly /></Field>
          <Field label="Phone">   <input value={lead.phone}   readOnly /></Field>
          <Field label="Email">   <input value={lead.email}   readOnly /></Field>
          <Field label="Source">  <input value={lead.source.replace(/_/g, " ")} readOnly /></Field>
          <Field label="Franchise"><input value={franchiseOf(lead.franchiseId)?.name ?? ""} readOnly /></Field>
          <Field label="Assigned To"><input value={lead.assignedTo} readOnly /></Field>
        </div>
        <div>
          <Field label="Bike of Interest">
            <div style={{ background: "#080a0f", border: "1px solid #1e2535", borderRadius: 8, padding: "10px 14px" }}>
              <div style={{ fontSize: 14 }}>{bike?.img} {bike?.brand} {bike?.model}</div>
              <div style={{ fontSize: 10, color: "#475569", marginTop: 4 }}>{bike?.variant} · {bike?.cc}cc · {bike?.category}</div>
              {p && <div style={{ fontSize: 12, color: "#f97316", marginTop: 6, fontWeight: 600 }}>On-Road: {formatINR(onRoad)}</div>}
            </div>
          </Field>
          <Field label="Pipeline Stage">
            <select value={stage} onChange={e => setStage(e.target.value as Lead["stage"])}>
              {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </Field>
          <Field label="Lead Score">
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <ScoreBadge score={lead.score} />
              <div style={{ flex: 1, background: "#1e2535", borderRadius: 4, height: 6 }}>
                <div style={{
                  width: `${lead.score}%`, height: "100%", borderRadius: 4,
                  background: lead.score >= 80 ? "#10b981" : lead.score >= 60 ? "#f59e0b" : "#ef4444",
                }} />
              </div>
            </div>
          </Field>
          <Field label="Follow-up Date"><input value={lead.followUp ?? ""} readOnly /></Field>
          <Field label="Created">       <input value={lead.createdAt}       readOnly /></Field>
        </div>
      </div>

      <div style={{ marginTop: 8, borderTop: "1px solid #1e2535", paddingTop: 20 }}>
        <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 12 }}>
          Notes & Activity
        </div>
        <div style={{ maxHeight: 100, overflowY: "auto", marginBottom: 10 }}>
          {notes.length === 0
            ? <div style={{ fontSize: 11, color: "#3d4a5e" }}>No notes yet</div>
            : notes.map((n, i) => (
              <div key={i} style={{ fontSize: 12, padding: "6px 0", borderBottom: "1px solid #1e2535", color: "#94a3b8" }}>
                → {n}
              </div>
            ))
          }
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            placeholder="Add note..."
            value={note}
            onChange={e => setNote(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") addNote(); }}
          />
          <Btn variant="ghost" size="sm" onClick={addNote}>Add</Btn>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 20, paddingTop: 20, borderTop: "1px solid #1e2535" }}>
        <Btn onClick={save}>💾 Save Changes</Btn>
        <Btn variant="whatsapp" onClick={openQuote}>📲 Generate Quote</Btn>
        <Btn variant="ghost" onClick={onClose} style={{ marginLeft: "auto" }}>Cancel</Btn>
      </div>
    </Modal>
  );
}

// ─── ADD LEAD MODAL ───────────────────────────────────────────────────────────

function AddLeadModal({ onClose, onAdd }: { onClose: () => void; onAdd: (l: Lead) => void }) {
  const [form, setForm] = useState({
    name: "", phone: "", email: "",
    bikeId: "b1", franchiseId: "f1", source: "website", assignedTo: "",
  });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.name || !form.phone) return;
    onAdd({
      ...form,
      id: "l" + uid(), stage: "new",
      score: Math.floor(Math.random() * 30 + 60),
      followUp: today(), notes: [], createdAt: today(),
    } as Lead);
    onClose();
  };

  return (
    <Modal title="Add New Lead" onClose={onClose}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <Field label="Customer Name" required>
          <input placeholder="Full name" value={form.name} onChange={e => set("name", e.target.value)} />
        </Field>
        <Field label="Phone" required>
          <input placeholder="10-digit mobile" value={form.phone} onChange={e => set("phone", e.target.value)} />
        </Field>
        <Field label="Email">
          <input placeholder="email@example.com" value={form.email} onChange={e => set("email", e.target.value)} />
        </Field>
        <Field label="Source">
          <select value={form.source} onChange={e => set("source", e.target.value)}>
            {SOURCES.map(s => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
          </select>
        </Field>
        <Field label="Bike of Interest">
          <select value={form.bikeId} onChange={e => set("bikeId", e.target.value)}>
            {MASTER_BIKES.map(b => <option key={b.id} value={b.id}>{b.brand} {b.model}</option>)}
          </select>
        </Field>
        <Field label="Assign to Franchise">
          <select value={form.franchiseId} onChange={e => set("franchiseId", e.target.value)}>
            {FRANCHISES.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
        </Field>
        <Field label="Assigned To (Exec)">
          <input placeholder="Sales exec name" value={form.assignedTo} onChange={e => set("assignedTo", e.target.value)} />
        </Field>
      </div>
      <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
        <Btn onClick={submit}>+ Create Lead</Btn>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
      </div>
    </Modal>
  );
}

// ─── LEADS PAGE ───────────────────────────────────────────────────────────────

interface LeadsProps {
  leads: Lead[];
  setLeads: (fn: (ls: Lead[]) => Lead[]) => void;
  pricing: Record<string, PricingEntry>;
  setActiveTab: (t: string) => void;
  setQuoteTarget: (l: Lead) => void;
  franchise: string;
}

export default function Leads({
  leads, setLeads, pricing, setActiveTab, setQuoteTarget, franchise,
}: LeadsProps) {
  const [filter, setFilter] = useState({ stage: "all", source: "all", search: "" });
  const [selected, setSelected] = useState<Lead | null>(null);
  const [adding, setAdding]     = useState(false);

  const filtered = leads.filter(l => {
    if (franchise !== "all" && l.franchiseId !== franchise) return false;
    if (filter.stage  !== "all" && l.stage  !== filter.stage)  return false;
    if (filter.source !== "all" && l.source !== filter.source)  return false;
    if (filter.search && !l.name.toLowerCase().includes(filter.search.toLowerCase()) && !l.phone.includes(filter.search)) return false;
    return true;
  });

  const updateLead  = (updated: Lead) => setLeads(ls => ls.map(l => l.id === updated.id ? updated : l));
  const stageChange = (id: string, stage: string) => setLeads(ls => ls.map(l => l.id === id ? { ...l, stage: stage as Lead["stage"] } : l));
  const addLead     = (lead: Lead) => setLeads(ls => [lead, ...ls]);

  return (
    <div className="fade-up">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Leads</div>
          <div style={{ fontSize: 12, color: "#475569" }}>
            {filtered.length} leads {franchise !== "all" ? `· ${franchiseOf(franchise)?.name}` : "· All Franchises"}
          </div>
        </div>
        <Btn onClick={() => setAdding(true)}>+ New Lead</Btn>
      </div>

      {/* Filters */}
      <Card style={{ marginBottom: 16, padding: "16px 20px" }}>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <input
            placeholder="🔍 Search name or phone..."
            value={filter.search}
            onChange={e => setFilter(f => ({ ...f, search: e.target.value }))}
            style={{ flex: 1, minWidth: 200 }}
          />
          <select value={filter.stage} onChange={e => setFilter(f => ({ ...f, stage: e.target.value }))} style={{ width: 140 }}>
            <option value="all">All Stages</option>
            {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
          <select value={filter.source} onChange={e => setFilter(f => ({ ...f, source: e.target.value }))} style={{ width: 140 }}>
            <option value="all">All Sources</option>
            {SOURCES.map(s => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
          </select>
        </div>
      </Card>

      {/* Stage pills */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        {STAGES.map(s => (
          <div
            key={s.id}
            onClick={() => setFilter(f => ({ ...f, stage: f.stage === s.id ? "all" : s.id }))}
            style={{
              padding: "5px 14px", borderRadius: 100, fontSize: 11, cursor: "pointer",
              border: `1px solid ${s.color}40`,
              background: filter.stage === s.id ? s.bg : "transparent",
              color: filter.stage === s.id ? s.color : "#475569",
            }}
          >
            {s.label} · {leads.filter(l => (franchise === "all" || l.franchiseId === franchise) && l.stage === s.id).length}
          </div>
        ))}
      </div>

      <Card style={{ padding: 0, overflow: "hidden" }}>
        {/* Table header */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 140px 130px 120px 100px 80px",
          gap: 16, padding: "10px 20px", background: "#080a0f", borderBottom: "1px solid #1e2535",
        }}>
          {["Customer", "Bike", "Stage", "Source", "Score", "Follow-up"].map(h => (
            <div key={h} style={{ fontSize: 10, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }}>{h}</div>
          ))}
        </div>
        {filtered.length === 0 ? (
          <div style={{ padding: 48, textAlign: "center", color: "#3d4a5e", fontSize: 13 }}>No leads found</div>
        ) : (
          filtered.map(l => (
            <LeadRow key={l.id} lead={l} onSelect={setSelected} onStageChange={stageChange} />
          ))
        )}
      </Card>

      {selected && (
        <LeadDetail
          lead={selected} onClose={() => setSelected(null)}
          onUpdate={updateLead} pricing={pricing}
          setActiveTab={setActiveTab} setQuoteTarget={setQuoteTarget}
        />
      )}
      {adding && <AddLeadModal onClose={() => setAdding(false)} onAdd={addLead} />}
    </div>
  );
}
