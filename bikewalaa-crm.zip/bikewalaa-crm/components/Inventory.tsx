"use client";
import React, { useState } from "react";
import { InventoryItem, MASTER_BIKES, FRANCHISES, franchiseOf, bikeOf, uid } from "./data";
import { Btn, Badge, Card, Modal, Field } from "./ui";

interface Props {
  inventory: InventoryItem[];
  setInventory: (fn: (inv: InventoryItem[]) => InventoryItem[]) => void;
  franchise: string;
}

const statusColor = (s: string) =>
  s === "available" ? "#10b981" : s === "reserved" ? "#f59e0b" : "#ef4444";
const statusBg = (s: string) =>
  s === "available" ? "rgba(16,185,129,0.1)" : s === "reserved" ? "rgba(245,158,11,0.1)" : "rgba(239,68,68,0.1)";

export default function Inventory({ inventory, setInventory, franchise }: Props) {
  const [adding, setAdding] = useState(false);
  const [form, setForm]     = useState({ bikeId: "b1", franchiseId: "f1", color: "", stock: "1" });
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const filtered = franchise === "all" ? inventory : inventory.filter(i => i.franchiseId === franchise);

  const grouped = MASTER_BIKES.map(bike => ({
    bike,
    items: filtered.filter(i => i.bikeId === bike.id),
    totalStock: filtered.filter(i => i.bikeId === bike.id).reduce((a, i) => a + i.stock, 0),
  })).filter(g => franchise === "all" || g.items.length > 0);

  const addStock = () => {
    if (!form.color) return;
    const exists = inventory.find(
      i => i.bikeId === form.bikeId && i.franchiseId === form.franchiseId && i.color === form.color
    );
    if (exists) {
      setInventory(inv => inv.map(i =>
        i.id === exists.id ? { ...i, stock: i.stock + Number(form.stock) } : i
      ));
    } else {
      setInventory(inv => [...inv, {
        id: "i" + uid(), bikeId: form.bikeId, franchiseId: form.franchiseId,
        status: "available", color: form.color,
        chassis: "NEW" + uid().toUpperCase(), stock: Number(form.stock),
      }]);
    }
    setAdding(false);
    setForm({ bikeId: "b1", franchiseId: "f1", color: "", stock: "1" });
  };

  const updateStock = (id: string, delta: number) => {
    setInventory(inv => inv.map(i => {
      if (i.id !== id) return i;
      const ns = Math.max(0, i.stock + delta);
      return { ...i, stock: ns, status: ns === 0 ? "out_of_stock" : "available" };
    }));
  };

  const totalUnits     = filtered.reduce((a, i) => a + i.stock, 0);
  const availableUnits = filtered.filter(i => i.status === "available").reduce((a, i) => a + i.stock, 0);
  const reservedUnits  = filtered.filter(i => i.status === "reserved").reduce((a, i) => a + i.stock, 0);
  const oosCount       = filtered.filter(i => i.status === "out_of_stock").length;

  return (
    <div className="fade-up">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Inventory</div>
          <div style={{ fontSize: 12, color: "#475569" }}>
            {totalUnits} total units · {franchise !== "all" ? franchiseOf(franchise)?.name : "All Franchises"}
          </div>
        </div>
        <Btn onClick={() => setAdding(true)}>+ Add Stock</Btn>
      </div>

      {/* Summary */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
        <div style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 10, padding: "12px 20px" }}>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 700, color: "#10b981" }}>{availableUnits}</div>
          <div style={{ fontSize: 10, color: "#475569" }}>Available</div>
        </div>
        <div style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.25)", borderRadius: 10, padding: "12px 20px" }}>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 700, color: "#f59e0b" }}>{reservedUnits}</div>
          <div style={{ fontSize: 10, color: "#475569" }}>Reserved</div>
        </div>
        <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)", borderRadius: 10, padding: "12px 20px" }}>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 700, color: "#ef4444" }}>{oosCount}</div>
          <div style={{ fontSize: 10, color: "#475569" }}>Out of Stock</div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {grouped.map(({ bike, items, totalStock }) => (
          <Card key={bike.id} style={{ padding: 0, overflow: "hidden" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 16,
              padding: "16px 20px",
              borderBottom: items.length > 0 ? "1px solid #1e2535" : "none",
              background: "#080a0f",
            }}>
              <div style={{ fontSize: 24 }}>{bike.img}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15 }}>{bike.brand} {bike.model}</div>
                <div style={{ fontSize: 11, color: "#475569" }}>{bike.variant} · {bike.cc}cc · {bike.category}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{
                  fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 700,
                  color: totalStock > 5 ? "#10b981" : totalStock > 0 ? "#f59e0b" : "#ef4444",
                }}>
                  {totalStock}
                </div>
                <div style={{ fontSize: 10, color: "#475569" }}>total units</div>
              </div>
            </div>

            {items.map(item => (
              <div key={item.id} style={{
                display: "flex", alignItems: "center", gap: 16,
                padding: "12px 20px", borderBottom: "1px solid #0d1117",
              }}>
                <div style={{ fontSize: 10, color: "#475569", width: 120 }}>
                  {franchiseOf(item.franchiseId)?.name}
                </div>
                <div style={{ fontSize: 12, color: "#94a3b8" }}>{item.color}</div>
                <Badge color={statusColor(item.status)} bg={statusBg(item.status)}>
                  {item.status.replace(/_/g, " ")}
                </Badge>
                <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
                  <Btn variant="ghost" size="sm" onClick={() => updateStock(item.id, -1)}>−</Btn>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18, minWidth: 30, textAlign: "center" }}>
                    {item.stock}
                  </div>
                  <Btn variant="ghost" size="sm" onClick={() => updateStock(item.id, 1)}>+</Btn>
                </div>
              </div>
            ))}
            {items.length === 0 && (
              <div style={{ padding: "12px 20px", fontSize: 12, color: "#3d4a5e" }}>No stock at this franchise</div>
            )}
          </Card>
        ))}
      </div>

      {adding && (
        <Modal title="Add Stock" onClose={() => setAdding(false)} width={440}>
          <Field label="Bike">
            <select value={form.bikeId} onChange={e => set("bikeId", e.target.value)}>
              {MASTER_BIKES.map(b => <option key={b.id} value={b.id}>{b.brand} {b.model}</option>)}
            </select>
          </Field>
          <Field label="Franchise">
            <select value={form.franchiseId} onChange={e => set("franchiseId", e.target.value)}>
              {FRANCHISES.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
          </Field>
          <Field label="Color Variant">
            <input placeholder="e.g. Pearl Black" value={form.color} onChange={e => set("color", e.target.value)} />
          </Field>
          <Field label="Units to Add">
            <input type="number" min={1} value={form.stock} onChange={e => set("stock", e.target.value)} />
          </Field>
          <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
            <Btn onClick={addStock}>Add to Inventory</Btn>
            <Btn variant="ghost" onClick={() => setAdding(false)}>Cancel</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}
