"use client";
import React, { useState, useCallback } from "react";
import "@/app/globals.css";
import {
  Lead, InventoryItem, PricingEntry,
  initLeads, initInventory, initPricing,
} from "./data";
import { Toast } from "./ui";
import Sidebar      from "./Sidebar";
import Dashboard    from "./Dashboard";
import Leads        from "./Leads";
import Inventory    from "./Inventory";
import Pricing      from "./Pricing";
import Quotations   from "./Quotations";

export default function CRM() {
  const [activeTab,    setActiveTab]    = useState("dashboard");
  const [franchise,    setFranchise]    = useState("all");
  const [leads,        setLeads]        = useState<Lead[]>(initLeads());
  const [inventory,    setInventory]    = useState<InventoryItem[]>(initInventory());
  const [pricing,      setPricing]      = useState<Record<string, PricingEntry>>(initPricing());
  const [quoteTarget,  setQuoteTarget]  = useState<Lead | null>(null);
  const [toast,        setToast]        = useState<{ msg: string; type: "success" | "error" | "info" } | null>(null);

  const showToast = useCallback((msg: string, type: "success" | "error" | "info" = "success") => {
    setToast({ msg, type });
  }, []);

  const handleSetLeads = useCallback((fn: (ls: Lead[]) => Lead[]) => {
    setLeads(fn);
    showToast("Lead updated successfully");
  }, [showToast]);

  const handleSetInventory = useCallback((fn: (inv: InventoryItem[]) => InventoryItem[]) => {
    setInventory(fn);
    showToast("Inventory updated");
  }, [showToast]);

  const handleSetPricing = useCallback((fn: (p: Record<string, PricingEntry>) => Record<string, PricingEntry>) => {
    setPricing(fn);
    showToast("Pricing saved · Changes live");
  }, [showToast]);

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#080a0f" }}>
      <Sidebar
        active={activeTab} setActive={setActiveTab}
        franchise={franchise} setFranchise={setFranchise}
      />

      <main style={{
        marginLeft: 220, flex: 1,
        padding: "32px 32px 48px",
        overflowX: "hidden", minHeight: "100vh",
      }}>
        {activeTab === "dashboard"  && <Dashboard  leads={leads} inventory={inventory} pricing={pricing} />}
        {activeTab === "leads"      && <Leads       leads={leads} setLeads={handleSetLeads} pricing={pricing} setActiveTab={setActiveTab} setQuoteTarget={setQuoteTarget} franchise={franchise} />}
        {activeTab === "inventory"  && <Inventory   inventory={inventory} setInventory={handleSetInventory} franchise={franchise} />}
        {activeTab === "pricing"    && <Pricing     pricing={pricing} setPricing={handleSetPricing} />}
        {activeTab === "quotations" && <Quotations  leads={leads} pricing={pricing} quoteTarget={quoteTarget} setQuoteTarget={setQuoteTarget} />}
      </main>

      {toast && (
        <Toast msg={toast.msg} type={toast.type} onDone={() => setToast(null)} />
      )}
    </div>
  );
}
