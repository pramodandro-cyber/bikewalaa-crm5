"use client";
import React from "react";
import {
  Lead, InventoryItem, PricingEntry,
  FRANCHISES, STAGES,
  franchiseOf, formatINR, calcOnRoad,
} from "./data";
import { Card } from "./ui";

interface Props {
  leads: Lead[];
  inventory: InventoryItem[];
  pricing: Record<string, PricingEntry>;
}

const StatCard = ({
  label, value, sub, color = "#f97316", icon,
}: { label: string; value: string | number; sub?: string; color?: string; icon: string }) => (
  <Card className="fade-up">
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <div>
        <div style={{ fontSize: 10, color: "#64748b", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>
          {label}
        </div>
        <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 32, fontWeight: 800, color, lineHeight: 1 }}>
          {value}
        </div>
        {sub && <div style={{ fontSize: 11, color: "#475569", marginTop: 6 }}>{sub}</div>}
      </div>
      <div style={{ fontSize: 28, opacity: 0.4 }}>{icon}</div>
    </div>
  </Card>
);

export default function Dashboard({ leads, inventory, pricing }: Props) {
  const totalLeads  = leads.length;
  const delivered   = leads.filter(l => l.stage === "delivered").length;
  const convRate    = totalLeads ? ((delivered / totalLeads) * 100).toFixed(1) : "0.0";
  const revenue     = delivered * 84500;
  const totalStock  = inventory.reduce((a, i) => a + i.stock, 0);
  const oos         = inventory.filter(i => i.status === "out_of_stock").length;
  const stageCount  = (id: string) => leads.filter(l => l.stage === id).length;

  return (
    <div className="fade-up">
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>
          Dashboard
        </div>
        <div style={{ fontSize: 12, color: "#475569" }}>
          City Pilot · Mumbai & Navi Mumbai ·{" "}
          {new Date().toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16, marginBottom: 32 }}>
        <StatCard label="Total Leads"  value={totalLeads} sub={`${stageCount("new")} new today`} color="#3b82f6" icon="◎" />
        <StatCard label="Conversions"  value={delivered}  sub={`${convRate}% conv. rate`}        color="#10b981" icon="✓" />
        <StatCard label="Revenue"      value={formatINR(revenue)} sub="Estimated GMV"            color="#f97316" icon="◇" />
        <StatCard label="Total Stock"  value={totalStock} sub={`${oos} out of stock`}            color="#8b5cf6" icon="▦" />
      </div>

      {/* Pipeline overview */}
      <Card style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 20 }}>
          Pipeline Overview
        </div>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4 }}>
          {STAGES.map(s => (
            <div key={s.id} style={{
              flex: 1, minWidth: 90,
              background: s.bg, border: `1px solid ${s.color}30`,
              borderRadius: 10, padding: "14px 12px", textAlign: "center",
            }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 800, color: s.color }}>
                {stageCount(s.id)}
              </div>
              <div style={{ fontSize: 10, color: "#475569", marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Franchise performance */}
      <Card>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 20 }}>
          Franchise Performance
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {FRANCHISES.map(f => {
            const fLeads     = leads.filter(l => l.franchiseId === f.id);
            const fDelivered = fLeads.filter(l => l.stage === "delivered").length;
            const fRate      = fLeads.length ? ((fDelivered / fLeads.length) * 100).toFixed(0) : "0";
            const fInv       = inventory.filter(i => i.franchiseId === f.id).reduce((a, i) => a + i.stock, 0);
            return (
              <div key={f.id} style={{
                display: "flex", alignItems: "center", gap: 16,
                padding: "12px 0", borderBottom: "1px solid #1e2535",
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 10,
                  background: "rgba(249,115,22,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14,
                }}>🏪</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{f.name}</div>
                  <div style={{ fontSize: 10, color: "#475569" }}>{f.city} · {f.owner}</div>
                </div>
                <div style={{ textAlign: "center", minWidth: 50 }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18, color: "#3b82f6" }}>{fLeads.length}</div>
                  <div style={{ fontSize: 9, color: "#475569" }}>leads</div>
                </div>
                <div style={{ textAlign: "center", minWidth: 50 }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18, color: "#10b981" }}>{fDelivered}</div>
                  <div style={{ fontSize: 9, color: "#475569" }}>sold</div>
                </div>
                <div style={{ minWidth: 80 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#475569", marginBottom: 4 }}>
                    <span>{fRate}%</span><span>conv.</span>
                  </div>
                  <div style={{ background: "#1e2535", borderRadius: 4, height: 4, overflow: "hidden" }}>
                    <div style={{
                      width: `${fRate}%`, height: "100%",
                      background: "linear-gradient(90deg, #f97316, #fbbf24)", borderRadius: 4,
                    }} />
                  </div>
                </div>
                <div style={{ textAlign: "center", minWidth: 50 }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 18, color: "#8b5cf6" }}>{fInv}</div>
                  <div style={{ fontSize: 9, color: "#475569" }}>stock</div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
