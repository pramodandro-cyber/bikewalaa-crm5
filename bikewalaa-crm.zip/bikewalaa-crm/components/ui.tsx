"use client";
import React, { useEffect, CSSProperties, ReactNode } from "react";

// ─── BTN ──────────────────────────────────────────────────────────────────────

type BtnVariant = "primary" | "ghost" | "danger" | "success" | "whatsapp";
type BtnSize    = "sm" | "md";

interface BtnProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: BtnVariant;
  size?: BtnSize;
  style?: CSSProperties;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
}

export const Btn = ({
  children, onClick, variant = "primary", size = "md", style: sx = {}, disabled, type = "button",
}: BtnProps) => {
  const base: CSSProperties = {
    display: "inline-flex", alignItems: "center", gap: 6,
    fontFamily: "'DM Mono', monospace", fontWeight: 500,
    border: "none", cursor: disabled ? "not-allowed" : "pointer",
    borderRadius: 8, transition: "all 0.18s", opacity: disabled ? 0.5 : 1,
    fontSize: size === "sm" ? 11 : 12,
    padding: size === "sm" ? "6px 12px" : "10px 18px",
  };
  const variants: Record<BtnVariant, CSSProperties> = {
    primary:  { background: "#f97316", color: "#000" },
    ghost:    { background: "transparent", color: "#94a3b8", border: "1px solid #1e2535" },
    danger:   { background: "rgba(239,68,68,0.12)",   color: "#f87171", border: "1px solid rgba(239,68,68,0.25)"   },
    success:  { background: "rgba(16,185,129,0.12)",  color: "#34d399", border: "1px solid rgba(16,185,129,0.25)"  },
    whatsapp: { background: "rgba(37,211,102,0.15)",  color: "#25d366", border: "1px solid rgba(37,211,102,0.35)"  },
  };
  return (
    <button type={type} style={{ ...base, ...variants[variant], ...sx }} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
};

// ─── BADGE ────────────────────────────────────────────────────────────────────

export const Badge = ({ children, color, bg }: { children: ReactNode; color: string; bg: string }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 4,
    padding: "3px 10px", borderRadius: 100, fontSize: 10, fontWeight: 500,
    color, background: bg, border: `1px solid ${color}40`,
  }}>
    {children}
  </span>
);

// ─── CARD ─────────────────────────────────────────────────────────────────────

export const Card = ({
  children, style: sx = {}, className = "",
}: { children: ReactNode; style?: CSSProperties; className?: string }) => (
  <div className={className} style={{
    background: "#0d1117", border: "1px solid #1e2535", borderRadius: 14, padding: 24, ...sx,
  }}>
    {children}
  </div>
);

// ─── MODAL ────────────────────────────────────────────────────────────────────

export const Modal = ({
  title, onClose, children, width = 560,
}: { title: string; onClose: () => void; children: ReactNode; width?: number }) => (
  <div
    style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(4px)", zIndex: 1000,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 16,
    }}
    onClick={e => { if (e.target === e.currentTarget) onClose(); }}
  >
    <div className="scale-in" style={{
      background: "#0d1117", border: "1px solid #1e2535", borderRadius: 16,
      width: "100%", maxWidth: width, maxHeight: "90vh", overflow: "auto",
    }}>
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "20px 24px", borderBottom: "1px solid #1e2535",
      }}>
        <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 16 }}>{title}</span>
        <Btn variant="ghost" size="sm" onClick={onClose}>✕</Btn>
      </div>
      <div style={{ padding: 24 }}>{children}</div>
    </div>
  </div>
);

// ─── FIELD ────────────────────────────────────────────────────────────────────

export const Field = ({
  label, children, required,
}: { label: string; children: ReactNode; required?: boolean }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{
      display: "block", fontSize: 10, color: "#64748b",
      letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 6,
    }}>
      {label}{required && <span style={{ color: "#f97316" }}> *</span>}
    </label>
    {children}
  </div>
);

// ─── TOAST ────────────────────────────────────────────────────────────────────

type ToastType = "success" | "error" | "info";

export const Toast = ({
  msg, type = "success", onDone,
}: { msg: string; type?: ToastType; onDone: () => void }) => {
  useEffect(() => {
    const t = setTimeout(onDone, 3000);
    return () => clearTimeout(t);
  }, [onDone]);

  const colors: Record<ToastType, string> = {
    success: "#10b981", error: "#ef4444", info: "#3b82f6",
  };
  const icons: Record<ToastType, string> = {
    success: "✓", error: "✕", info: "ℹ",
  };
  return (
    <div className="slide-in" style={{
      position: "fixed", bottom: 24, right: 24, zIndex: 2000,
      background: "#0d1117", border: `1px solid ${colors[type]}40`,
      borderLeft: `3px solid ${colors[type]}`, borderRadius: 10,
      padding: "12px 20px", display: "flex", alignItems: "center", gap: 10, fontSize: 12,
    }}>
      <span style={{ color: colors[type] }}>{icons[type]}</span>
      {msg}
    </div>
  );
};

// ─── SCORE BADGE ──────────────────────────────────────────────────────────────

export const ScoreBadge = ({ score }: { score: number }) => {
  const color = score >= 80 ? "#10b981" : score >= 60 ? "#f59e0b" : "#ef4444";
  return (
    <div style={{
      width: 36, height: 36, borderRadius: "50%",
      border: `2px solid ${color}`, display: "flex", alignItems: "center",
      justifyContent: "center", fontSize: 10, fontWeight: 700, color,
    }}>
      {score}
    </div>
  );
};
