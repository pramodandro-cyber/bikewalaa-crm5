"use client";
import React, { useState, useEffect } from "react";
import {
  Lead, PricingEntry, Quote, EMI_RATES,
  bikeOf, calcOnRoad, calcEMI, formatINR, uid,
} from "./data";
import { Btn, Badge, Card, Modal, Field, ScoreBadge } from "./ui";
import { stageOf } from "./data";

interface Props {
  leads: Lead[];
  pricing: Record<string, PricingEntry>;
  quoteTarget: Lead | null;
  setQuoteTarget: (l: Lead | null) => void;
}

// ─── QUOTE CREATOR ────────────────────────────────────────────────────────────

function QuoteCreator({
  lead, onClose, onSave,
}: { lead: Lead; onClose: () => void; onSave: (q: Quote) => void }) {
  const bike          = bikeOf(lead.bikeId);
  const [pricing, setPricingState] = useState<PricingEntry | null>(null);

  // We pass pricing via prop instead — re-done below with proper prop threading
  const [tenure, setTenure]           = useState(24);
  const [downPayment, setDownPayment] = useState("0");
  const [customNote, setCustomNote]   = useState("");
  const [includeOffers, setInclude]   = useState(true);

  return <div>Loading…</div>; // placeholder — see QuoteCreatorFull below
}

// ─── QUOTE CREATOR FULL (pricing-aware) ──────────────────────────────────────

function QuoteCreatorFull({
  lead, pricing, onClose, onSave,
}: { lead: Lead; pricing: Record<string, PricingEntry>; onClose: () => void; onSave: (q: Quote) => void }) {
  const bike = bikeOf(lead.bikeId);
  const p    = pricing[lead.bikeId];
  const onRoad = p ? calcOnRoad(p) : 0;

  const [tenure,       setTenure]       = useState(24);
  const [downPayment,  setDownPayment]  = useState("0");
  const [customNote,   setCustomNote]   = useState("");
  const [includeOffers, setInclude]     = useState(true);

  const offerSavings = includeOffers && p ? p.offers.length * 3000 : 0;
  const finalPrice   = onRoad - offerSavings;
  const loanAmt      = finalPrice - Number(downPayment);
  const emi          = calcEMI(loanAmt, tenure, EMI_RATES[tenure] ?? 10.5);

  const msgLines = [
    `🏍️ *${bike?.brand} ${bike?.model} — ${bike?.variant}*`,
    ``,
    `💰 *On-Road Price: ${formatINR(finalPrice)}*`,
    offerSavings > 0 ? `🎁 Offer Savings: ${formatINR(offerSavings)}` : null,
    Number(downPayment) > 0 ? `💵 Down Payment: ${formatINR(Number(downPayment))}` : null,
    `📅 EMI: *${formatINR(emi)}/mo × ${tenure} months*`,
    `📊 Rate: ${EMI_RATES[tenure]}% p.a.`,
    ``,
    `✅ Zero documentation hassle`,
    `🚀 Fast delivery · All cities`,
    customNote ? `\n📌 ${customNote}` : null,
    ``,
    `⏰ Quote valid for 48 hours`,
    ``,
    `📞 Contact: Bikewalaa · www.bikewalaa.com`,
  ].filter(Boolean).join("\n");

  const waLink = `https://wa.me/91${lead.phone}?text=${encodeURIComponent(msgLines)}`;

  const handleSend = () => {
    const q: Quote = {
      id: "q" + uid(),
      leadId: lead.id, leadName: lead.name,
      phone: lead.phone, bikeId: lead.bikeId,
      bikeName: `${bike?.brand} ${bike?.model}`,
      tenure, emi, onRoad: finalPrice,
      status: "sent", sentAt: new Date().toISOString(),
      waLink, msg: msgLines,
    };
    onSave(q);
    window.open(waLink, "_blank");
    onClose();
  };

  return (
    <Modal title={`WhatsApp Quote · ${lead.name}`} onClose={onClose} width={680}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Config */}
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, marginBottom: 16, fontSize: 13 }}>
            Configure Quote
          </div>
          <Field label="Customer">    <input value={`${lead.name} · ${lead.phone}`} readOnly /></Field>
          <Field label="Bike">        <input value={`${bike?.brand} ${bike?.model} · ${bike?.variant}`} readOnly /></Field>
          <Field label="On-Road Price"><input value={formatINR(onRoad)} readOnly /></Field>
          <Field label="EMI Tenure">
            <select value={tenure} onChange={e => setTenure(Number(e.target.value))}>
              {Object.entries(EMI_RATES).map(([m, r]) => (
                <option key={m} value={m}>{m} months @ {r}%</option>
              ))}
            </select>
          </Field>
          <Field label="Down Payment (₹)">
            <input type="number" value={downPayment} onChange={e => setDownPayment(e.target.value)} placeholder="0 = zero down payment" />
          </Field>
          <Field label="Personal Note">
            <textarea rows={2} value={customNote} onChange={e => setCustomNote(e.target.value)} placeholder="Add a personal message..." />
          </Field>
          {p && p.offers.length > 0 && (
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0" }}>
              <input type="checkbox" checked={includeOffers} onChange={e => setInclude(e.target.checked)} style={{ width: "auto" }} />
              <label style={{ fontSize: 12, color: "#94a3b8" }}>Include offers ({p.offers.join(", ")})</label>
            </div>
          )}
        </div>

        {/* Preview */}
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, marginBottom: 16, fontSize: 13 }}>
            WhatsApp Preview
          </div>
          <div style={{ background: "rgba(37,211,102,0.06)", border: "1px solid rgba(37,211,102,0.2)", borderRadius: 12, padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, paddingBottom: 10, borderBottom: "1px solid rgba(37,211,102,0.15)" }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "rgba(37,211,102,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🛵</div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#25d366" }}>Bikewalaa</div>
                <div style={{ fontSize: 9, color: "#475569" }}>Business Account</div>
              </div>
            </div>
            <pre style={{ fontSize: 11, color: "#94a3b8", whiteSpace: "pre-wrap", fontFamily: "'DM Mono', monospace", lineHeight: 1.7 }}>
              {msgLines}
            </pre>
          </div>

          <div style={{ marginTop: 16, background: "#080a0f", border: "1px solid #1e2535", borderRadius: 10, padding: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ fontSize: 11, color: "#475569" }}>Monthly EMI</span>
              <span style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 700, color: "#3b82f6" }}>{formatINR(emi)}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <span style={{ fontSize: 11, color: "#475569" }}>Total Payout</span>
              <span style={{ fontSize: 13, color: "#94a3b8" }}>{formatINR(emi * tenure)}</span>
            </div>
            {offerSavings > 0 && (
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontSize: 11, color: "#fbbf24" }}>Offer Savings</span>
                <span style={{ fontSize: 13, color: "#fbbf24" }}>−{formatINR(offerSavings)}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 20, paddingTop: 20, borderTop: "1px solid #1e2535" }}>
        <Btn variant="whatsapp" onClick={handleSend}>📲 Send on WhatsApp</Btn>
        <Btn variant="ghost" onClick={onClose} style={{ marginLeft: "auto" }}>Cancel</Btn>
      </div>
    </Modal>
  );
}

// ─── QUOTATIONS PAGE ──────────────────────────────────────────────────────────

export default function Quotations({ leads, pricing, quoteTarget, setQuoteTarget }: Props) {
  const [quotes,   setQuotes]   = useState<Quote[]>([]);
  const [creating, setCreating] = useState<Lead | null>(null);

  useEffect(() => {
    if (quoteTarget) { setCreating(quoteTarget); setQuoteTarget(null); }
  }, [quoteTarget, setQuoteTarget]);

  const hotLeads = leads.filter(l => ["interested", "finance", "contacted"].includes(l.stage));

  return (
    <div className="fade-up">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>Quotations</div>
          <div style={{ fontSize: 12, color: "#475569" }}>WhatsApp quote generator · {quotes.length} quotes sent this session</div>
        </div>
      </div>

      {/* Hot leads queue */}
      <Card style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>
          Hot Leads — Ready to Quote
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {hotLeads.slice(0, 6).map(lead => {
            const bike  = bikeOf(lead.bikeId);
            const p     = pricing[lead.bikeId];
            const stage = stageOf(lead.stage);
            return (
              <div key={lead.id} style={{
                display: "flex", alignItems: "center", gap: 16,
                padding: "10px 16px", background: "#080a0f",
                borderRadius: 10, border: "1px solid #1e2535",
              }}>
                <ScoreBadge score={lead.score} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{lead.name}</div>
                  <div style={{ fontSize: 11, color: "#475569" }}>{bike?.brand} {bike?.model} · {lead.phone}</div>
                </div>
                <Badge color={stage.color} bg={stage.bg}>{stage.label}</Badge>
                {p && <div style={{ fontSize: 12, color: "#f97316", fontWeight: 600 }}>{formatINR(calcOnRoad(p))}</div>}
                <Btn variant="whatsapp" size="sm" onClick={() => setCreating(lead)}>📲 Quote</Btn>
              </div>
            );
          })}
          {hotLeads.length === 0 && (
            <div style={{ fontSize: 12, color: "#3d4a5e", padding: 12 }}>No hot leads at the moment</div>
          )}
        </div>
      </Card>

      {/* Sent quotes */}
      <Card>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>
          Quotes Sent This Session
        </div>
        {quotes.length === 0 ? (
          <div style={{ padding: "32px 0", textAlign: "center", color: "#3d4a5e", fontSize: 13 }}>
            No quotes sent yet. Use the hot leads above to fire your first quote! 🚀
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {quotes.map(q => (
              <div key={q.id} style={{
                display: "flex", alignItems: "center", gap: 16,
                padding: "12px 16px", background: "#080a0f",
                borderRadius: 10, border: "1px solid #1e2535",
              }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", background: "rgba(37,211,102,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>📲</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{q.leadName}</div>
                  <div style={{ fontSize: 11, color: "#475569" }}>{q.bikeName} · {q.phone}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 12, color: "#f97316", fontWeight: 600 }}>{formatINR(q.onRoad)}</div>
                  <div style={{ fontSize: 10, color: "#475569" }}>EMI {formatINR(q.emi)}/mo × {q.tenure}</div>
                </div>
                <Badge color="#25d366" bg="rgba(37,211,102,0.1)">Sent</Badge>
                <Btn variant="whatsapp" size="sm" onClick={() => window.open(q.waLink, "_blank")}>Resend</Btn>
              </div>
            ))}
          </div>
        )}
      </Card>

      {creating && (
        <QuoteCreatorFull
          lead={creating}
          pricing={pricing}
          onClose={() => setCreating(null)}
          onSave={q => setQuotes(qs => [q, ...qs])}
        />
      )}
    </div>
  );
}
