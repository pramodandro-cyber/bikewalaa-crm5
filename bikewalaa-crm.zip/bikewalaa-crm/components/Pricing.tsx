"use client";
import React, { useState } from "react";
import {
  PricingEntry, MASTER_BIKES, EMI_RATES, Bike,
  calcOnRoad, calcEMI, formatINR,
} from "./data";
import { Btn, Badge, Card, Modal, Field } from "./ui";

interface Props {
  pricing: Record<string, PricingEntry>;
  setPricing: (fn: (p: Record<string, PricingEntry>) => Record<string, PricingEntry>) => void;
}

interface EmiTarget { bike: Bike; p: PricingEntry; onRoad: number }

export default function Pricing({ pricing, setPricing }: Props) {
  const [editing, setEditing]       = useState<string | null>(null);
  const [editForm, setEditForm]     = useState<PricingEntry | null>(null);
  const [emiPreview, setEmiPreview] = useState<EmiTarget | null>(null);

  const openEdit = (bikeId: string) => {
    setEditing(bikeId);
    setEditForm({ ...pricing[bikeId] });
  };

  const saveEdit = () => {
    if (!editing || !editForm) return;
    setPricing(p => ({
      ...p,
      [editing]: {
        ...editForm,
        exShowroom: Number(editForm.exShowroom),
        rto:        Number(editForm.rto),
        insurance:  Number(editForm.insurance),
        margin:     Number(editForm.margin),
        minFloor:   Number(editForm.minFloor),
      },
    }));
    setEditing(null);
    setEditForm(null);
  };

  const set = (k: keyof PricingEntry, v: string | string[]) =>
    setEditForm(f => f ? { ...f, [k]: v } : f);

  const previewOnRoad = editForm
    ? Number(editForm.exShowroom) + Number(editForm.rto) + Number(editForm.insurance) + Number(editForm.margin)
    : 0;

  return (
    <div className="fade-up">
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 4 }}>
          Dynamic Pricing
        </div>
        <div style={{ fontSize: 12, color: "#475569" }}>
          Central pricing control · Margin-protected · EMI calculator included
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {MASTER_BIKES.map(bike => {
          const p = pricing[bike.id];
          if (!p) return null;
          const onRoad   = calcOnRoad(p);
          const marginOk = p.margin >= p.minFloor;
          return (
            <Card key={bike.id} style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "16px 20px", flexWrap: "wrap" }}>
                <div style={{ fontSize: 26 }}>{bike.img}</div>
                <div style={{ flex: 1, minWidth: 160 }}>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 2 }}>
                    {bike.brand} {bike.model} · {bike.variant}
                  </div>
                  <div style={{ fontSize: 11, color: "#475569" }}>{bike.cc}cc · {bike.fuel} · {bike.category}</div>
                  {p.offers.length > 0 && (
                    <div style={{ display: "flex", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
                      {p.offers.map((o, i) => <Badge key={i} color="#fbbf24" bg="rgba(251,191,36,0.1)">🎁 {o}</Badge>)}
                    </div>
                  )}
                </div>

                <div style={{ display: "flex", gap: 20, alignItems: "center", flexWrap: "wrap" }}>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 10, color: "#475569", marginBottom: 2 }}>Ex-Showroom</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{formatINR(p.exShowroom)}</div>
                  </div>
                  <span style={{ color: "#1e2535" }}>+</span>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 10, color: "#475569", marginBottom: 2 }}>RTO + Ins.</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{formatINR(p.rto + p.insurance)}</div>
                  </div>
                  <span style={{ color: "#1e2535" }}>+</span>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 10, color: marginOk ? "#10b981" : "#ef4444", marginBottom: 2 }}>
                      Margin {marginOk ? "✓" : "⚠"}
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: marginOk ? "#10b981" : "#ef4444" }}>
                      {formatINR(p.margin)}
                    </div>
                  </div>
                  <span style={{ color: "#1e2535" }}>=</span>
                  <div style={{
                    textAlign: "right",
                    background: "rgba(249,115,22,0.08)", border: "1px solid rgba(249,115,22,0.2)",
                    borderRadius: 8, padding: "8px 14px",
                  }}>
                    <div style={{ fontSize: 10, color: "#f97316", marginBottom: 2 }}>On-Road</div>
                    <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 18, fontWeight: 800, color: "#f97316" }}>
                      {formatINR(onRoad)}
                    </div>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8, marginLeft: 8 }}>
                  <Btn variant="ghost" size="sm" onClick={() => setEmiPreview({ bike, p, onRoad })}>EMI</Btn>
                  <Btn size="sm" onClick={() => openEdit(bike.id)}>Edit</Btn>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Edit modal */}
      {editing && editForm && (
        <Modal title={`Edit Pricing · ${MASTER_BIKES.find(b => b.id === editing)?.brand} ${MASTER_BIKES.find(b => b.id === editing)?.model}`} onClose={() => setEditing(null)}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <Field label="Ex-Showroom Price (₹)">
              <input type="number" value={editForm.exShowroom} onChange={e => set("exShowroom", e.target.value)} />
            </Field>
            <Field label="RTO Charges (₹)">
              <input type="number" value={editForm.rto} onChange={e => set("rto", e.target.value)} />
            </Field>
            <Field label="Insurance (₹)">
              <input type="number" value={editForm.insurance} onChange={e => set("insurance", e.target.value)} />
            </Field>
            <Field label="Franchise Margin (₹)">
              <input type="number" value={editForm.margin} onChange={e => set("margin", e.target.value)} />
            </Field>
            <Field label="Minimum Margin Floor (₹)">
              <input type="number" value={editForm.minFloor} onChange={e => set("minFloor", e.target.value)} />
            </Field>
          </div>
          <div style={{
            background: "rgba(249,115,22,0.06)", border: "1px solid rgba(249,115,22,0.2)",
            borderRadius: 10, padding: 16, marginTop: 8,
          }}>
            <div style={{ fontSize: 11, color: "#f97316", marginBottom: 6 }}>New On-Road Price</div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 26, fontWeight: 800, color: "#f97316" }}>
              {formatINR(previewOnRoad)}
            </div>
            {Number(editForm.margin) < Number(editForm.minFloor) && (
              <div style={{ color: "#ef4444", fontSize: 11, marginTop: 8 }}>
                ⚠ Margin below floor ({formatINR(editForm.minFloor)})
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
            <Btn onClick={saveEdit}>Save Pricing</Btn>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
          </div>
        </Modal>
      )}

      {/* EMI modal */}
      {emiPreview && (
        <Modal title={`EMI Calculator · ${emiPreview.bike.brand} ${emiPreview.bike.model}`} onClose={() => setEmiPreview(null)} width={480}>
          <div style={{
            background: "rgba(249,115,22,0.06)", border: "1px solid rgba(249,115,22,0.2)",
            borderRadius: 10, padding: 16, marginBottom: 20, textAlign: "center",
          }}>
            <div style={{ fontSize: 11, color: "#f97316", marginBottom: 4 }}>On-Road Price</div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 32, fontWeight: 800, color: "#f97316" }}>
              {formatINR(emiPreview.onRoad)}
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {Object.entries(EMI_RATES).map(([months, rate]) => {
              const emi = calcEMI(emiPreview.onRoad, Number(months), rate);
              return (
                <div key={months} style={{
                  background: "#080a0f", border: "1px solid #1e2535", borderRadius: 10,
                  padding: 16, textAlign: "center",
                }}>
                  <div style={{ fontSize: 10, color: "#475569", marginBottom: 8 }}>
                    {months} months · {rate}% p.a.
                  </div>
                  <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 800, color: "#3b82f6" }}>
                    {formatINR(emi)}
                  </div>
                  <div style={{ fontSize: 10, color: "#475569", marginTop: 4 }}>per month</div>
                  <div style={{ fontSize: 10, color: "#3d4a5e", marginTop: 2 }}>
                    Total: {formatINR(emi * Number(months))}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ fontSize: 10, color: "#3d4a5e", marginTop: 16, textAlign: "center" }}>
            * Indicative EMI · Actual rate subject to NBFC / bank approval
          </div>
        </Modal>
      )}
    </div>
  );
}
