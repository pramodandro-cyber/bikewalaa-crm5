// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface Franchise {
  id: string;
  name: string;
  city: string;
  owner: string;
}

export interface Bike {
  id: string;
  brand: string;
  model: string;
  variant: string;
  cc: number;
  fuel: string;
  category: string;
  img: string;
}

export interface InventoryItem {
  id: string;
  bikeId: string;
  franchiseId: string;
  status: "available" | "reserved" | "out_of_stock";
  color: string;
  chassis: string;
  stock: number;
}

export interface PricingEntry {
  exShowroom: number;
  rto: number;
  insurance: number;
  margin: number;
  minFloor: number;
  offers: string[];
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  bikeId: string;
  franchiseId: string;
  stage: StageId;
  source: string;
  score: number;
  followUp: string | null;
  notes: string[];
  createdAt: string;
  assignedTo: string;
}

export interface Quote {
  id: string;
  leadId: string;
  leadName: string;
  phone: string;
  bikeId: string;
  bikeName: string;
  tenure: number;
  emi: number;
  onRoad: number;
  status: "sent" | "responded" | "converted";
  sentAt: string;
  waLink: string;
  msg: string;
}

export type StageId =
  | "new" | "contacted" | "interested"
  | "finance" | "booked" | "delivered" | "lost";

export interface Stage {
  id: StageId;
  label: string;
  color: string;
  bg: string;
}

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

export const FRANCHISES: Franchise[] = [
  { id: "f1", name: "Andheri West",  city: "Mumbai",      owner: "Rajesh Patel" },
  { id: "f2", name: "Thane Central", city: "Mumbai",      owner: "Meera Shah"   },
  { id: "f3", name: "Vashi",         city: "Navi Mumbai", owner: "Suresh Kumar" },
  { id: "f4", name: "Kharghar",      city: "Navi Mumbai", owner: "Priya Joshi"  },
];

export const MASTER_BIKES: Bike[] = [
  { id:"b1", brand:"Honda",  model:"Activa 6G",      variant:"Standard", cc:109, fuel:"Petrol", category:"Scooter",   img:"🛵" },
  { id:"b2", brand:"TVS",    model:"Jupiter 125",    variant:"Classic",  cc:124, fuel:"Petrol", category:"Scooter",   img:"🛵" },
  { id:"b3", brand:"Hero",   model:"Splendor+",      variant:"IBS",      cc:97,  fuel:"Petrol", category:"Commuter",  img:"🏍️" },
  { id:"b4", brand:"Bajaj",  model:"Pulsar N150",    variant:"Standard", cc:149, fuel:"Petrol", category:"Sports",    img:"🏍️" },
  { id:"b5", brand:"Honda",  model:"CB Shine",       variant:"Disc",     cc:124, fuel:"Petrol", category:"Commuter",  img:"🏍️" },
  { id:"b6", brand:"TVS",    model:"Apache RTR 160", variant:"4V",       cc:159, fuel:"Petrol", category:"Sports",    img:"🏍️" },
  { id:"b7", brand:"Suzuki", model:"Access 125",     variant:"CBS",      cc:124, fuel:"Petrol", category:"Scooter",   img:"🛵" },
  { id:"b8", brand:"Hero",   model:"Glamour",        variant:"IBS",      cc:124, fuel:"Petrol", category:"Commuter",  img:"🏍️" },
];

export const STAGES: Stage[] = [
  { id:"new",       label:"New",       color:"#3b82f6", bg:"rgba(59,130,246,0.12)"  },
  { id:"contacted", label:"Contacted", color:"#8b5cf6", bg:"rgba(139,92,246,0.12)"  },
  { id:"interested",label:"Interested",color:"#f59e0b", bg:"rgba(245,158,11,0.12)"  },
  { id:"finance",   label:"Finance",   color:"#ec4899", bg:"rgba(236,72,153,0.12)"  },
  { id:"booked",    label:"Booked",    color:"#f97316", bg:"rgba(249,115,22,0.12)"  },
  { id:"delivered", label:"Delivered", color:"#10b981", bg:"rgba(16,185,129,0.12)"  },
  { id:"lost",      label:"Lost",      color:"#6b7280", bg:"rgba(107,114,128,0.12)" },
];

export const SOURCES = [
  "website","whatsapp","meta_ads","google_ads","walk_in","referral",
];

export const EMI_RATES: Record<number, number> = {
  12: 9.5, 18: 10.0, 24: 10.5, 36: 11.0, 48: 11.5,
};

// ─── SEED DATA ────────────────────────────────────────────────────────────────

export const initPricing = (): Record<string, PricingEntry> => ({
  b1: { exShowroom:72000,  rto:8200,  insurance:4800, margin:3500, minFloor:2000, offers:["Diwali Cashback ₹3,000"] },
  b2: { exShowroom:78000,  rto:8800,  insurance:5200, margin:4000, minFloor:2500, offers:[] },
  b3: { exShowroom:68000,  rto:7500,  insurance:4200, margin:3000, minFloor:1800, offers:["Zero Accessories Free"] },
  b4: { exShowroom:98000,  rto:11200, insurance:6800, margin:5000, minFloor:3000, offers:["Festival ₹5,000 off"] },
  b5: { exShowroom:75000,  rto:8500,  insurance:5000, margin:3800, minFloor:2200, offers:[] },
  b6: { exShowroom:115000, rto:13200, insurance:8200, margin:6000, minFloor:4000, offers:[] },
  b7: { exShowroom:81000,  rto:9200,  insurance:5400, margin:4200, minFloor:2800, offers:["Free Helmet"] },
  b8: { exShowroom:73000,  rto:8200,  insurance:4900, margin:3600, minFloor:2000, offers:[] },
});

export const initInventory = (): InventoryItem[] => [
  { id:"i1",  bikeId:"b1", franchiseId:"f1", status:"available",    color:"Pearl Black",  chassis:"MH01AL123456", stock:12 },
  { id:"i2",  bikeId:"b1", franchiseId:"f2", status:"available",    color:"Matte Blue",   chassis:"MH01AL123457", stock:8  },
  { id:"i3",  bikeId:"b2", franchiseId:"f1", status:"available",    color:"Silver",       chassis:"MH01TV234567", stock:5  },
  { id:"i4",  bikeId:"b3", franchiseId:"f3", status:"available",    color:"Red",          chassis:"NM01HR345678", stock:18 },
  { id:"i5",  bikeId:"b4", franchiseId:"f1", status:"available",    color:"Black Red",    chassis:"MH01BJ456789", stock:3  },
  { id:"i6",  bikeId:"b4", franchiseId:"f4", status:"out_of_stock", color:"Blue",         chassis:"NM01BJ456790", stock:0  },
  { id:"i7",  bikeId:"b6", franchiseId:"f2", status:"available",    color:"Racing Red",   chassis:"MH01TV567890", stock:4  },
  { id:"i8",  bikeId:"b7", franchiseId:"f3", status:"reserved",     color:"Pearl White",  chassis:"NM01SZ678901", stock:2  },
  { id:"i9",  bikeId:"b5", franchiseId:"f4", status:"available",    color:"Athletic Blue",chassis:"NM01HN789012", stock:7  },
  { id:"i10", bikeId:"b8", franchiseId:"f2", status:"available",    color:"Vibrant Red",  chassis:"MH01HR890123", stock:9  },
];

export const initLeads = (): Lead[] => [
  { id:"l1", name:"Rahul Sharma",  phone:"9876543210", email:"rahul@gmail.com",  bikeId:"b1", franchiseId:"f1", stage:"new",       source:"website",   score:82,  followUp:"2024-11-02", notes:[],                                        createdAt:"2024-10-28", assignedTo:"Amit V."   },
  { id:"l2", name:"Priya Mehta",   phone:"9823456789", email:"priya@gmail.com",  bikeId:"b4", franchiseId:"f1", stage:"interested",source:"meta_ads",  score:91,  followUp:"2024-10-31", notes:["Wants black color","Needs finance"],      createdAt:"2024-10-26", assignedTo:"Rohit S."  },
  { id:"l3", name:"Arun Kumar",    phone:"9711234567", email:"arun@gmail.com",   bikeId:"b2", franchiseId:"f2", stage:"finance",   source:"walk_in",   score:95,  followUp:"2024-10-30", notes:["HDFC loan applied","Docs submitted"],     createdAt:"2024-10-24", assignedTo:"Meera S."  },
  { id:"l4", name:"Sneha Patil",   phone:"9634567890", email:"sneha@gmail.com",  bikeId:"b3", franchiseId:"f3", stage:"booked",    source:"whatsapp",  score:98,  followUp:"2024-11-05", notes:["Deposit paid ₹5000","Delivery scheduled"],createdAt:"2024-10-22", assignedTo:"Suresh K." },
  { id:"l5", name:"Vikram Joshi",  phone:"9567890123", email:"vikram@gmail.com", bikeId:"b6", franchiseId:"f2", stage:"contacted", source:"google_ads",score:65,  followUp:"2024-11-01", notes:[],                                        createdAt:"2024-10-29", assignedTo:"Meera S."  },
  { id:"l6", name:"Anita Singh",   phone:"9456789012", email:"anita@gmail.com",  bikeId:"b1", franchiseId:"f4", stage:"delivered", source:"referral",  score:100, followUp:null,         notes:["Delivered 27 Oct"],                       createdAt:"2024-10-15", assignedTo:"Priya J."  },
  { id:"l7", name:"Deepak Rao",    phone:"9345678901", email:"deepak@gmail.com", bikeId:"b7", franchiseId:"f3", stage:"lost",      source:"website",   score:30,  followUp:null,         notes:["Went to competitor"],                     createdAt:"2024-10-20", assignedTo:"Suresh K." },
  { id:"l8", name:"Kavita More",   phone:"9234567890", email:"kavita@gmail.com", bikeId:"b5", franchiseId:"f4", stage:"new",       source:"meta_ads",  score:70,  followUp:"2024-11-03", notes:[],                                        createdAt:"2024-10-30", assignedTo:"Priya J."  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────

export const calcOnRoad = (p: PricingEntry) =>
  p.exShowroom + p.rto + p.insurance + p.margin;

export const calcEMI = (amount: number, months: number, rate: number) => {
  const r = rate / 100 / 12;
  return Math.round(
    (amount * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1)
  );
};

export const formatINR = (n: number) =>
  "₹" + Number(n).toLocaleString("en-IN");

export const stageOf = (id: string): Stage =>
  STAGES.find(s => s.id === id) ?? STAGES[0];

export const bikeOf = (id: string) =>
  MASTER_BIKES.find(b => b.id === id);

export const franchiseOf = (id: string) =>
  FRANCHISES.find(f => f.id === id);

export const uid = () => Math.random().toString(36).slice(2, 9);

export const today = () => new Date().toISOString().split("T")[0];
