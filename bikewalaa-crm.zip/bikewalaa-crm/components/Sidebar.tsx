"use client";
import React from "react";
import { FRANCHISES } from "./data";

const NAV = [
  { id: "dashboard",  icon: "◈", label: "Dashboard"  },
  { id: "leads",      icon: "◎", label: "Leads"       },
  { id: "inventory",  icon: "▦", label: "Inventory"   },
  { id: "pricing",    icon: "◇", label: "Pricing"     },
  { id: "quotations", icon: "✦", label: "Quotations"  },
];

interface Props {
  active: string;
  setActive: (id: string) => void;
  franchise: string;
  setFranchise: (id: string) => void;
}

export default function Sidebar({ active, setActive, franchise, setFranchise }: Props) {
  return (
    <aside style={{
      width: 220, background: "#080a0f", borderRight: "1px solid #1e2535",
      display: "flex", flexDirection: "column", flexShrink: 0,
      position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid #1e2535" }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20, color: "#f97316" }}>
          Bikewalaa
        </div>
        <div style={{ fontSize: 9, color: "#3d4a5e", letterSpacing: "0.15em", textTransform: "uppercase", marginTop: 2 }}>
          CRM Platform · MVP
        </div>
      </div>

      {/* Franchise selector */}
      <div style={{ padding: "12px 16px", borderBottom: "1px solid #1e2535" }}>
        <div style={{ fontSize: 9, color: "#3d4a5e", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 6 }}>
          Active Franchise
        </div>
        <select value={franchise} onChange={e => setFranchise(e.target.value)} style={{ padding: "8px 10px", fontSize: 11 }}>
          <option value="all">All Franchises (Admin)</option>
          {FRANCHISES.map(f => (
            <option key={f.id} value={f.id}>{f.name}</option>
          ))}
        </select>
      </div>

      {/* Nav */}
      <nav style={{ padding: "12px 10px", flex: 1 }}>
        {NAV.map(n => (
          <div
            key={n.id}
            onClick={() => setActive(n.id)}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "11px 14px", borderRadius: 10, marginBottom: 2, cursor: "pointer",
              transition: "all 0.15s",
              background: active === n.id ? "rgba(249,115,22,0.1)" : "transparent",
              color: active === n.id ? "#f97316" : "#475569",
            }}
          >
            <span style={{ fontSize: 16 }}>{n.icon}</span>
            <span style={{ fontSize: 12, fontWeight: active === n.id ? 600 : 400 }}>{n.label}</span>
            {active === n.id && (
              <div style={{ marginLeft: "auto", width: 3, height: 16, background: "#f97316", borderRadius: 2 }} />
            )}
          </div>
        ))}
      </nav>

      {/* Status */}
      <div style={{ padding: 16, borderTop: "1px solid #1e2535" }}>
        <div style={{ fontSize: 10, color: "#3d4a5e" }}>v1.0 MVP · City Pilot</div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 4 }}>
          <div style={{
            width: 6, height: 6, borderRadius: "50%", background: "#10b981",
            animation: "pulse2 2s infinite",
          }} />
          <span style={{ fontSize: 10, color: "#10b981" }}>Live · 4 Franchises</span>
        </div>
      </div>
    </aside>
  );
}
